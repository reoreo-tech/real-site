<div>
    これは{{ config('app.name', 'Laravel') }}のテストメールです。
</div>
<div>
    この度はご購入ありがとうございます。
</div>
<div>
    入金が確認され次第、発送いたします。
</div>
