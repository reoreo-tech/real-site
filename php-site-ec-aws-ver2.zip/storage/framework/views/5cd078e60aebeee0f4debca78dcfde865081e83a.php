<div>
    これは<?php echo e(config('app.name', 'Laravel')); ?>のテストメールです。
</div>
<div>
    この度はご購入ありがとうございます。
</div>
<div>
    入金が確認され次第、発送いたします。
</div>
<?php /**PATH /var/www/resources/views/buy/mail.blade.php ENDPATH**/ ?>